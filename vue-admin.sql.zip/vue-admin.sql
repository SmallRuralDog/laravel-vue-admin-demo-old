-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: 2020-04-22 18:49:06
-- 服务器版本： 5.7.29-log
-- PHP Version: 7.2.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vue-admin`
--

-- --------------------------------------------------------

--
-- 表的结构 `goods`
--

CREATE TABLE `goods` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL COMMENT '用户ID',
  `store_id` int(11) NOT NULL COMMENT '商家ID',
  `goods_class_path` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `goods_class_id` int(11) NOT NULL COMMENT '分类ID',
  `brand_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '商品名称',
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '描述',
  `putaway` tinyint(1) NOT NULL DEFAULT '0' COMMENT '上架',
  `one_attr` tinyint(1) NOT NULL,
  `price` decimal(8,2) DEFAULT '0.00',
  `cost_price` decimal(8,2) DEFAULT '0.00',
  `line_price` decimal(8,2) DEFAULT '0.00',
  `stock_num` int(11) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 转存表中的数据 `goods`
--

INSERT INTO `goods` (`id`, `user_id`, `store_id`, `goods_class_path`, `goods_class_id`, `brand_id`, `name`, `description`, `putaway`, `one_attr`, `price`, `cost_price`, `line_price`, `stock_num`, `created_at`, `updated_at`) VALUES
(9, 2, 0, '[10]', 10, 2, '21', '12', 0, 1, '21.00', '2.00', '20.00', 2, '2020-04-14 06:12:47', '2020-04-14 06:12:47');

-- --------------------------------------------------------

--
-- 表的结构 `goods_attrs`
--

CREATE TABLE `goods_attrs` (
  `id` int(10) UNSIGNED NOT NULL,
  `store_id` int(11) NOT NULL COMMENT '店铺ID',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '属性名称',
  `sort` smallint(6) NOT NULL COMMENT '排序',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 转存表中的数据 `goods_attrs`
--

INSERT INTO `goods_attrs` (`id`, `store_id`, `name`, `sort`, `created_at`, `updated_at`) VALUES
(1, 0, '颜色', 1, '2020-03-23 03:20:47', '2020-03-23 03:20:47'),
(2, 0, '尺码', 1, '2020-03-22 11:54:39', '2020-03-22 11:54:39'),
(3, 0, '777', 1, '2020-03-27 10:39:13', '2020-03-27 10:39:13'),
(4, 0, '15', 1, '2020-03-29 05:10:07', '2020-03-29 05:10:07'),
(5, 0, '222', 1, '2020-03-29 05:45:18', '2020-03-29 05:45:18'),
(6, 0, '标签', 1, '2020-03-29 12:28:36', '2020-03-29 12:28:36'),
(7, 0, '11111', 1, '2020-03-31 06:35:20', '2020-03-31 06:35:20'),
(8, 0, '尺寸', 1, '2020-04-01 02:08:23', '2020-04-01 02:08:23'),
(9, 0, '5555', 1, '2020-04-01 02:43:28', '2020-04-01 02:43:28'),
(10, 0, '44', 1, '2020-04-01 07:30:21', '2020-04-01 07:30:21'),
(11, 0, '123', 1, '2020-04-08 13:37:15', '2020-04-08 13:37:15'),
(12, 0, '7777', 1, '2020-04-13 07:22:24', '2020-04-13 07:22:24'),
(13, 0, 'xxx', 1, '2020-04-15 09:03:29', '2020-04-15 09:03:29'),
(14, 0, '666', 1, '2020-04-16 12:50:44', '2020-04-16 12:50:44'),
(15, 0, 'jhgj', 1, '2020-04-19 05:37:15', '2020-04-19 05:37:15'),
(16, 0, '新规格', 1, '2020-04-19 10:04:44', '2020-04-19 10:04:44');

-- --------------------------------------------------------

--
-- 表的结构 `goods_attr_map`
--

CREATE TABLE `goods_attr_map` (
  `id` bigint(20) NOT NULL,
  `goods_id` int(11) NOT NULL COMMENT '产品ID',
  `attr_id` int(11) NOT NULL COMMENT '属性ID',
  `alias` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '别名',
  `index` int(11) NOT NULL DEFAULT '0' COMMENT '排序 asc'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- 表的结构 `goods_attr_values`
--

CREATE TABLE `goods_attr_values` (
  `id` int(10) UNSIGNED NOT NULL,
  `goods_attr_id` int(11) NOT NULL COMMENT '规格ID',
  `store_id` int(11) NOT NULL COMMENT '店铺ID',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '属性名称',
  `sort` smallint(6) NOT NULL DEFAULT '0' COMMENT '排序'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 转存表中的数据 `goods_attr_values`
--

INSERT INTO `goods_attr_values` (`id`, `goods_attr_id`, `store_id`, `name`, `sort`) VALUES
(1, 1, 0, '红色', 1),
(2, 1, 0, '白色', 1),
(3, 2, 0, 'XS', 1),
(4, 2, 0, 'S', 1),
(5, 2, 0, 'L', 1),
(6, 2, 0, 'XL', 1),
(7, 2, 0, 'XXL', 1),
(8, 1, 0, '黄色', 1),
(9, 1, 0, '黑色', 1),
(10, 1, 0, '橙色', 1),
(11, 1, 0, '绿色', 1),
(12, 1, 0, 'ooo', 1),
(13, 1, 0, 'gdf', 1),
(14, 1, 0, '啊啊啊', 1),
(15, 4, 0, '5555', 1),
(16, 5, 0, '2221', 1),
(17, 6, 0, '标签1', 1),
(18, 2, 0, '2323', 1),
(19, 6, 0, '2ef', 1),
(20, 6, 0, '77777', 1),
(21, 5, 0, '1111', 1),
(22, 7, 0, 'www', 1),
(23, 3, 0, '222', 1),
(24, 3, 0, '333', 1),
(25, 1, 0, '其他', 1),
(26, 3, 0, '444', 1),
(27, 2, 0, '33', 1),
(28, 1, 0, '红', 1),
(29, 2, 0, '0000', 1);

-- --------------------------------------------------------

--
-- 表的结构 `goods_attr_value_map`
--

CREATE TABLE `goods_attr_value_map` (
  `id` bigint(20) NOT NULL,
  `attr_map_id` int(11) NOT NULL COMMENT '产品属性关系ID',
  `goods_id` int(11) NOT NULL COMMENT '产品ID',
  `attr_id` int(11) NOT NULL COMMENT '属性ID',
  `attr_value_id` int(11) NOT NULL COMMENT '属性值ID',
  `alias` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '别名',
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '图片',
  `index` int(11) NOT NULL DEFAULT '0' COMMENT '排序 asc'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- 表的结构 `goods_classes`
--

CREATE TABLE `goods_classes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `parent_id` int(11) NOT NULL COMMENT '上级',
  `goods_class_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '分类标识',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '分类名称',
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '图标',
  `order` int(11) NOT NULL DEFAULT '1' COMMENT '排序',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 转存表中的数据 `goods_classes`
--

INSERT INTO `goods_classes` (`id`, `parent_id`, `goods_class_key`, `name`, `icon`, `order`, `status`, `created_at`, `updated_at`) VALUES
(3, 3, 'sss', 'sss', 'images/pic01-140x140.jpg', 1, 1, '2020-03-30 02:39:51', '2020-04-07 11:17:54'),
(4, 3, '00000000', '0000000000', 'images/timg.jpg', 1, 1, '2020-04-05 11:50:22', '2020-04-05 11:50:22'),
(5, 5, '的深V', '倒是', 'images/8f90bf61b744b97344c006c237dbd9ed.jpg', 1, 1, '2020-04-08 08:09:58', '2020-04-08 08:10:39'),
(6, 6, '是的', '是的', 'images/8f90bf61b744b97344c006c237dbd9ed.jpg', 0, 1, '2020-04-08 08:10:21', '2020-04-08 08:10:29'),
(11, 0, 'demo', 'demo', 'images/v2-b172db8c69dac7fa761fb3a1b5b2acf4_hd.jpg', 1, 1, '2020-04-20 07:21:22', '2020-04-20 07:21:22'),
(12, 11, 'ddaa', 'ddaa', 'images/back-orange.0c887f65.png', 1, 1, '2020-04-20 08:14:14', '2020-04-20 08:14:14');

-- --------------------------------------------------------

--
-- 表的结构 `goods_contents`
--

CREATE TABLE `goods_contents` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `goods_id` bigint(20) NOT NULL,
  `content` mediumtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 转存表中的数据 `goods_contents`
--

INSERT INTO `goods_contents` (`id`, `goods_id`, `content`) VALUES
(9, 9, '<p>2</p>');

-- --------------------------------------------------------

--
-- 表的结构 `goods_images`
--

CREATE TABLE `goods_images` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `goods_id` bigint(20) NOT NULL,
  `path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 转存表中的数据 `goods_images`
--

INSERT INTO `goods_images` (`id`, `goods_id`, `path`, `order`) VALUES
(14, 9, 'images/00001.jpg', 0),
(15, 9, 'images/01.jpg', 1);

-- --------------------------------------------------------

--
-- 表的结构 `goods_skus`
--

CREATE TABLE `goods_skus` (
  `id` int(10) UNSIGNED NOT NULL COMMENT '自增 sku_id',
  `goods_id` bigint(20) NOT NULL COMMENT '产品ID',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attr_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '销售属性标识 - 链接，按小到大排序',
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '0' COMMENT '图片',
  `price` decimal(8,2) NOT NULL COMMENT '价格',
  `cost_price` decimal(8,2) DEFAULT NULL COMMENT '成本价',
  `line_price` decimal(8,2) DEFAULT '0.00' COMMENT '划线价',
  `code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '编码',
  `sold_num` int(11) NOT NULL DEFAULT '0' COMMENT '销量',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态 1:enable, 0:disable, -1:deleted',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 转存表中的数据 `goods_skus`
--

INSERT INTO `goods_skus` (`id`, `goods_id`, `name`, `attr_key`, `image`, `price`, `cost_price`, `line_price`, `code`, `sold_num`, `status`, `created_at`, `updated_at`) VALUES
(11, 9, '21', '0', 'images/00001.jpg', '21.00', '0.00', '20.00', '', 0, 1, '2020-04-14 06:12:47', '2020-04-14 06:12:47');

-- --------------------------------------------------------

--
-- 表的结构 `goods_sku_attr_value_maps`
--

CREATE TABLE `goods_sku_attr_value_maps` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `goods_id` bigint(20) NOT NULL,
  `goods_sku_id` bigint(20) NOT NULL,
  `attr_id` int(11) NOT NULL DEFAULT '0',
  `attr_value_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 转存表中的数据 `goods_sku_attr_value_maps`
--

INSERT INTO `goods_sku_attr_value_maps` (`id`, `goods_id`, `goods_sku_id`, `attr_id`, `attr_value_id`) VALUES
(10, 3, 3, 1, 2),
(11, 3, 7, 1, 2),
(12, 3, 7, 5, 16),
(13, 3, 7, 2, 4),
(14, 3, 7, 4, 15),
(27, 7, 8, 1, 1),
(28, 7, 8, 3, 23),
(29, 7, 9, 1, 1),
(30, 7, 9, 3, 24);

-- --------------------------------------------------------

--
-- 表的结构 `goods_sku_stock`
--

CREATE TABLE `goods_sku_stock` (
  `id` int(10) UNSIGNED NOT NULL COMMENT '自增ID',
  `sku_id` int(11) NOT NULL COMMENT 'SKU ID',
  `goods_id` int(11) NOT NULL COMMENT '产品 ID',
  `quantity` int(11) NOT NULL COMMENT '库存',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态 1:enable, 0:disable, -1:deleted'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 转存表中的数据 `goods_sku_stock`
--

INSERT INTO `goods_sku_stock` (`id`, `sku_id`, `goods_id`, `quantity`, `status`) VALUES
(11, 11, 9, 2, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `goods`
--
ALTER TABLE `goods`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `goods_attrs`
--
ALTER TABLE `goods_attrs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `goods_attrs_store_id_name_unique` (`store_id`,`name`);

--
-- Indexes for table `goods_attr_map`
--
ALTER TABLE `goods_attr_map`
  ADD PRIMARY KEY (`id`),
  ADD KEY `goods_attr_map_goods_id_index` (`goods_id`);

--
-- Indexes for table `goods_attr_values`
--
ALTER TABLE `goods_attr_values`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `goods_attr_id` (`goods_attr_id`,`name`);

--
-- Indexes for table `goods_attr_value_map`
--
ALTER TABLE `goods_attr_value_map`
  ADD PRIMARY KEY (`id`),
  ADD KEY `goods_attr_value_map_attr_map_id_index` (`attr_map_id`),
  ADD KEY `goods_attr_value_map_goods_id_index` (`goods_id`);

--
-- Indexes for table `goods_classes`
--
ALTER TABLE `goods_classes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `goods_classes_goods_class_key_unique` (`goods_class_key`);

--
-- Indexes for table `goods_contents`
--
ALTER TABLE `goods_contents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `goods_images`
--
ALTER TABLE `goods_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `goods_skus`
--
ALTER TABLE `goods_skus`
  ADD PRIMARY KEY (`id`),
  ADD KEY `goods_skus_goods_id_attr_key_index` (`goods_id`,`attr_key`),
  ADD KEY `goods_skus_goods_id_index` (`goods_id`),
  ADD KEY `goods_skus_attr_key_index` (`attr_key`);

--
-- Indexes for table `goods_sku_attr_value_maps`
--
ALTER TABLE `goods_sku_attr_value_maps`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `goods_sku_stock`
--
ALTER TABLE `goods_sku_stock`
  ADD PRIMARY KEY (`id`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `goods`
--
ALTER TABLE `goods`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- 使用表AUTO_INCREMENT `goods_attrs`
--
ALTER TABLE `goods_attrs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- 使用表AUTO_INCREMENT `goods_attr_map`
--
ALTER TABLE `goods_attr_map`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- 使用表AUTO_INCREMENT `goods_attr_values`
--
ALTER TABLE `goods_attr_values`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- 使用表AUTO_INCREMENT `goods_attr_value_map`
--
ALTER TABLE `goods_attr_value_map`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- 使用表AUTO_INCREMENT `goods_classes`
--
ALTER TABLE `goods_classes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- 使用表AUTO_INCREMENT `goods_contents`
--
ALTER TABLE `goods_contents`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- 使用表AUTO_INCREMENT `goods_images`
--
ALTER TABLE `goods_images`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- 使用表AUTO_INCREMENT `goods_skus`
--
ALTER TABLE `goods_skus`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '自增 sku_id', AUTO_INCREMENT=12;

--
-- 使用表AUTO_INCREMENT `goods_sku_attr_value_maps`
--
ALTER TABLE `goods_sku_attr_value_maps`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- 使用表AUTO_INCREMENT `goods_sku_stock`
--
ALTER TABLE `goods_sku_stock`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '自增ID', AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
